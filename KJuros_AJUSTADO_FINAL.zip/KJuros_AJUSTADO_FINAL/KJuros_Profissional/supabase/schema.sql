-- KJuros: schema inicial multiempresa com isolamento por organização.
-- Execute no SQL Editor do Supabase em um projeto novo.
create extension if not exists pgcrypto;

create table if not exists public.organizations (
 id uuid primary key default gen_random_uuid(),
 name text not null,
 owner_id uuid not null references auth.users(id) on delete cascade,
 created_at timestamptz not null default now()
);
create table if not exists public.memberships (
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null references public.organizations(id) on delete cascade,
 user_id uuid not null references auth.users(id) on delete cascade,
 role text not null default 'owner' check (role in ('owner','admin','operator','viewer')),
 created_at timestamptz not null default now(),
 unique(organization_id,user_id)
);
create or replace function public.current_org_id()
returns uuid language sql stable security definer set search_path=public
as $$ select organization_id from public.memberships where user_id=auth.uid() order by created_at limit 1 $$;

create or replace function public.is_org_member(org uuid)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.memberships where organization_id=org and user_id=auth.uid()) $$;

create table if not exists public.clients (
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null default public.current_org_id() references public.organizations(id) on delete cascade,
 full_name text not null,
 phone text,
 email text,
 document_number text,
 notes text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table if not exists public.loans (
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null default public.current_org_id() references public.organizations(id) on delete cascade,
 client_id uuid not null references public.clients(id) on delete restrict,
 principal numeric(14,2) not null check(principal>0),
 interest_rate numeric(8,4) not null check(interest_rate>=0),
 installments_count integer not null check(installments_count between 1 and 360),
 total_amount numeric(14,2) not null check(total_amount>=principal),
 first_due_date date not null,
 status text not null default 'active' check(status in ('draft','active','paid','cancelled','defaulted')),
 notes text,
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);
create table if not exists public.installments (
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null default public.current_org_id() references public.organizations(id) on delete cascade,
 loan_id uuid not null references public.loans(id) on delete cascade,
 client_id uuid not null references public.clients(id) on delete cascade,
 installment_number integer not null check(installment_number>0),
 due_date date not null,
 amount_due numeric(14,2) not null check(amount_due>=0),
 amount_paid numeric(14,2) not null default 0 check(amount_paid>=0),
 status text not null default 'pending' check(status in ('pending','partial','paid','waived')),
 created_at timestamptz not null default now(),
 unique(loan_id,installment_number)
);
-- Compatibilidade: se a tabela installments já existia sem client_id, adiciona e preenche a coluna.
alter table public.installments add column if not exists client_id uuid references public.clients(id) on delete cascade;
update public.installments i
set client_id = l.client_id
from public.loans l
where i.loan_id = l.id and i.client_id is null;
alter table public.installments alter column client_id set not null;

create table if not exists public.payments (
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null default public.current_org_id() references public.organizations(id) on delete cascade,
 installment_id uuid not null references public.installments(id) on delete restrict,
 amount numeric(14,2) not null check(amount>0),
 paid_at date not null default current_date,
 payment_method text,
 reference text,
 notes text,
 created_by uuid default auth.uid(),
 created_at timestamptz not null default now()
);
create table if not exists public.audit_logs (
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null references public.organizations(id) on delete cascade,
 actor_id uuid default auth.uid(),
 action text not null,
 entity_type text not null,
 entity_id uuid,
 metadata jsonb not null default '{}'::jsonb,
 created_at timestamptz not null default now()
);

create or replace function public.bootstrap_new_user()
returns trigger language plpgsql security definer set search_path=public
as $$
declare org_id uuid;
begin
 insert into public.organizations(name,owner_id)
 values(coalesce(nullif(new.raw_user_meta_data->>'full_name',''),'Minha operação'),new.id)
 returning id into org_id;
 insert into public.memberships(organization_id,user_id,role) values(org_id,new.id,'owner');
 return new;
end $$;

drop trigger if exists on_auth_user_created_kjuros on auth.users;
create trigger on_auth_user_created_kjuros after insert on auth.users
for each row execute procedure public.bootstrap_new_user();

-- Garante organização para contas que já existiam antes da instalação deste SQL.
do $$
declare u record; org_id uuid;
begin
 for u in select id, raw_user_meta_data from auth.users where not exists (select 1 from public.memberships m where m.user_id = auth.users.id) loop
  insert into public.organizations(name,owner_id)
  values(coalesce(nullif(u.raw_user_meta_data->>'full_name',''),'Minha operação'),u.id)
  returning id into org_id;
  insert into public.memberships(organization_id,user_id,role) values(org_id,u.id,'owner');
 end loop;
end $$;

alter table public.organizations enable row level security;
alter table public.memberships enable row level security;
alter table public.clients enable row level security;
alter table public.loans enable row level security;
alter table public.installments enable row level security;
alter table public.payments enable row level security;
alter table public.audit_logs enable row level security;

drop policy if exists "members can view own org" on public.organizations;
create policy "members can view own org" on public.organizations for select using(public.is_org_member(id));
drop policy if exists "members can view memberships" on public.memberships;
create policy "members can view memberships" on public.memberships for select using(public.is_org_member(organization_id));
drop policy if exists "members manage clients" on public.clients;
create policy "members manage clients" on public.clients for all using(public.is_org_member(organization_id)) with check(public.is_org_member(organization_id));
drop policy if exists "members manage loans" on public.loans;
create policy "members manage loans" on public.loans for all using(public.is_org_member(organization_id)) with check(public.is_org_member(organization_id));
drop policy if exists "members manage installments" on public.installments;
create policy "members manage installments" on public.installments for all using(public.is_org_member(organization_id)) with check(public.is_org_member(organization_id));
drop policy if exists "members manage payments" on public.payments;
create policy "members manage payments" on public.payments for all using(public.is_org_member(organization_id)) with check(public.is_org_member(organization_id));
drop policy if exists "members view audit logs" on public.audit_logs;
create policy "members view audit logs" on public.audit_logs for select using(public.is_org_member(organization_id));
create index if not exists clients_org_name_idx on public.clients(organization_id,full_name);
create index if not exists loans_org_status_idx on public.loans(organization_id,status);
create index if not exists installments_org_due_idx on public.installments(organization_id,due_date,status);
create index if not exists payments_installment_idx on public.payments(installment_id);

-- NOTA: para operação comercial, adicionar convites/membros, permissões por papel,
-- procedures transacionais para baixa de pagamento e atualização de saldo,
-- validação server-side, auditoria automática e testes de RLS antes do lançamento.

-- Permissões SQL para o papel autenticado; as políticas RLS acima limitam cada usuário à própria organização.
grant usage on schema public to authenticated;
grant select on public.organizations, public.memberships, public.audit_logs to authenticated;
grant select, insert, update, delete on public.clients, public.loans, public.installments, public.payments to authenticated;
