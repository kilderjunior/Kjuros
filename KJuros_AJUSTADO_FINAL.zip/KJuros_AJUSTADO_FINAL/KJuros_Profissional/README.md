# KJuros — versão ajustada

## Executar no computador
Abra o CMD dentro de `KJuros_Profissional` (a pasta que contém `package.json`) e rode:

```bash
npm install
npm run dev
```

Não abra `index.html` com duplo clique. Para encerrar o servidor: `Ctrl + C`.

## Recursos incluídos nesta atualização
- Mostrar/ocultar senha na tela de acesso.
- Campos de login com `autocomplete` para o gerenciador de senhas do navegador (o Chrome pode perguntar se deseja salvar a senha; o app não guarda a senha em texto aberto).
- Tela de Configurações funcional, com preferências de notificação salvas neste navegador.
- Avisos do navegador para parcelas atrasadas e vencimentos nos próximos 3 dias, quando o app estiver aberto, a sessão estiver ativa e a permissão tiver sido concedida.
- Botão WhatsApp em cada parcela em aberto: prepara a mensagem com nome, parcela, valor e vencimento. O usuário revisa e envia manualmente.
- Manifesto, ícone e service worker para oferecer instalação como PWA depois da publicação em HTTPS.
- Ajustes responsivos para celular e telas menores.

## Limites importantes
- Notificações locais não funcionam com o navegador totalmente fechado. Para alertas automáticos em segundo plano será necessário configurar push com servidor/função agendada.
- WhatsApp abre a conversa com texto preenchido; o envio precisa ser confirmado pelo usuário. Envio automático exige API oficial do WhatsApp Business.
- Salvar senha é responsabilidade do gerenciador de senhas do navegador/telefone, não do banco de dados do KJuros.

## Supabase
A configuração local está em `.env.local`. Não publique esse arquivo no GitHub. No Netlify, configure em Site configuration → Environment variables:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

Use somente a chave pública `anon`/`publishable`; nunca use `service_role` ou `secret` no navegador.
O schema SQL existente está em `supabase/schema.sql`. Não execute novamente se as tabelas e políticas já foram criadas e existem dados reais, a menos que saiba quais migrações está aplicando.

## Publicar no Netlify
- Build command: `npm run build`
- Publish directory: `dist`
- Configure as duas variáveis Supabase acima e faça novo deploy.
- No Supabase → Authentication → URL Configuration, configure a URL final do site e Redirect URLs.

## Instalar no celular
Depois de publicar em HTTPS, abra o endereço no Chrome do celular → menu → `Instalar aplicativo` ou `Adicionar à tela inicial`.
